#include <stdio.h>
#include <string.h>
int lengthOfLastWord(char *s) {
    int length = 0;
    int i = strlen(s) - 1;
    // Skip trailing spaces
    while (i >= 0 && s[i] == ' ') {
        i--;
    }
    // Calculate length of last word
    while (i >= 0 && s[i] != ' ') {
        length++;
        i--;
    }
    return length;
}
int main() {
    char str[100];
    printf("Enter a sentence: ");
    fgets(str, sizeof(str), stdin);
    // Remove newline character if present
    int len = strlen(str);
    if (str[len - 1] == '\n') {
        str[len - 1] = '\0';
    }
    int result = lengthOfLastWord(str);
    printf("Length of the last word: %d\n", result);
    return 0;
}
/*Algorithm used 
1.Input Sentence: The program prompts the user to input a sentence.
2.Read Input: It reads the entire sentence (including spaces) using `fgets()` and stores it in the `str` array.
3.Removing Trailing Newline Character: It checks if there's a newline character at the end of the input string and replaces it with the null terminator `\0` to handle the string properly.
4.Length of Last Word Function (`lengthOfLastWord()`):
It starts from the end of the string and moves backward to skip any trailing spaces (if present).
Then, it counts characters until it finds a space or reaches the start of the string, calculating the length of the last word.
Returns the length of the last word.
5.Output: The main function calls `lengthOfLastWord()` with the user input string and prints the length of the last word.
This algorithm ensures the program takes the entire sentence as input, removes any trailing newline characters, and accurately determines the length of the last word in the given sentence.
*/





