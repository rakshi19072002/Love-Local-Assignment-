#include <stdio.h>
#include <string.h>
#include<stdlib.h>
char *shortestPalindrome(char *s) {
    int len = strlen(s);
    char rev_s[len * 2 + 1]; // Double the length to accommodate both strings
    // Create the reversed string of 's'
    for (int i = len - 1, j = 0; i >= 0; i--, j++) {
        rev_s[j] = s[i];
    }
    rev_s[len] = '\0';
    int i;
    for (i = 0; i < len; i++) {
        if (strncmp(s, &rev_s[i], len - i) == 0) {
            break;
        }
    }
    char *result = (char *)malloc((len + i + 1) * sizeof(char));
    strncpy(result, rev_s, i);
    strcpy(result + i, s);
    return result;
}
int main() {
    char input[100];
    printf("Enter the string: ");
    scanf("%s", input);
    char *result = shortestPalindrome(input);
    printf("Output: %s\n", result);
    free(result); // Free dynamically allocated memory
    return 0;
}
/* This algorithm aims to find the shortest palindrome by adding characters to the beginning of the input string. It follows these steps:

Reverse the input string 's'.
Compare 's' with different substrings starting from the reversed string to find the longest common palindrome between the reversed string and 's'.
Once the longest common palindrome is found, concatenate the remaining characters from the reversed string to the original input string to create the shortest palindrome.
Return this shortest palindrome.
The algorithm uses string manipulation techniques, such as reversing a string, comparing substrings, and manipulating memory to allocate space for the resulting string.
*/